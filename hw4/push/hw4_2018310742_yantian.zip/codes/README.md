# Sentence-level Sentiment Classification with RNN

1. Complete "cell.py" and "model.py";
2. Modify "main.py": 
   1. add return values of function train() and evaluate();
   2. add codes to draw necessary curve;
3. Using "python3 main.py" to run the code and can also support arguments list in "main.py";
| CellType | test acc | test loss |
| :------: | -------- | --------- |
| RNNCell  | 0.5350   | 1.0595    |
| GRUCell  | 0.5825   | 1.2509    |
| LSTMCell | 0.5765   | 1.0741    |
| LSTMCell2| 0.4113   | 1.0685    |
| GRUCell2 | 0.5945   | 1.2753    |
| GRUCell3 | 0.6466   | 0.9108    |
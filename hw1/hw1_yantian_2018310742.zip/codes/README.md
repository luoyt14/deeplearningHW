# MNIST Digits Classification with MLP

1. Complete "loss.py, layers.py";
2. Modify "solve_net.py": add return values of function train_net() and test_net();
3. Modify "run_mlp.py": modify network structure and add codes to draw necessary curve;
4. Use "python3 run_mlp.py" to run the code.